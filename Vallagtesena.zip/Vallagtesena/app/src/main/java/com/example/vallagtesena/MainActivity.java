package com.example.vallagtesena;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button signup, login;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUI();
        setupListeners();
    }

    void checkUsername () {
        boolean isValid = true;

        if (isEmpty(username)) {
            username.setError("You Must Enter an Username to Login !");
            isValid = false;
        }
        if (!isEmail(username)) {
                username.setError("Enter Valid Email !");
                isValid = false;
            }

        if (isValid) {
            String usernameValue = username.getText().toString();
            String passwordValue = password.getText().toString();
            if (usernameValue.equals("a@a.com") && passwordValue.equals("b")) {
               Intent i = new Intent(MainActivity.this, homepage.class);
               startActivity(i);
               this.finish();
            } else {
                Toast t = Toast.makeText(this, "Wrong email or password entered !", Toast.LENGTH_SHORT);
                t.show();
            }
        }
    }


    private void setupUI () {
        username = findViewById(R.id.username);
        password = findViewById(R.id.PasswordLogin);
        signup = findViewById(R.id.signup_button);
        login = findViewById(R.id.login_button);
    }

    private void setupListeners () {
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkUsername();
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, signup.class);
                startActivity(i);

            }
        });
    }

    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }


    boolean isEmpty (EditText text){
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }


}

