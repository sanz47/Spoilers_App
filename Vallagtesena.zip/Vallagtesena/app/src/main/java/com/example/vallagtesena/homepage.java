package com.example.vallagtesena;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class homepage extends AppCompatActivity {
    Button episodecount,episodewatched,movietime,moviecount,recentseries;
    TextView textepisodecount,textepisodewatched,textmovietime,textmoviecount;
    ImageView imageView;
    Integer a=300,b=223,c=101,d=46,e=42,f=54;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        episodecount=findViewById(R.id.episodecount);
        textepisodecount=findViewById(R.id.textepisodecount);

        episodewatched=findViewById(R.id.episodeswatched);
        textepisodewatched=findViewById(R.id.textepisodeswatched);

        movietime=findViewById(R.id.movietime);
        textmovietime=findViewById(R.id.textmovietime);

        moviecount=findViewById(R.id.moviecount);
        textmoviecount=findViewById(R.id.textmoviecount);

        recentseries=findViewById(R.id.recentmovies);

        episodecount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                episodecount.setVisibility(View.INVISIBLE);
                textepisodecount.setText(a + " Episodes ");
                episodecount.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        episodecount.setVisibility(view.VISIBLE);
                    }
                },3000);

            }
        });

        episodewatched.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                episodewatched.setVisibility(View.INVISIBLE);
                textepisodewatched.setText(c+" Hours " + d +" Minutes");
                episodewatched.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        episodewatched.setVisibility(view.VISIBLE);
                    }
                },3000);

            }
        });

        movietime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                movietime.setVisibility(View.INVISIBLE);
                textmovietime.setText(b + " Movies");
                movietime.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        movietime.setVisibility(view.VISIBLE);
                    }
                },3000);

            }
        });

        moviecount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moviecount.setVisibility(View.INVISIBLE);
                textmoviecount.setText(e+" Hours " + f +" Minutes");
                moviecount.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        moviecount.setVisibility(view.VISIBLE);
                    }
                },3000);

            }
        });

        recentseries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(homepage.this, SeriesList.class);
                startActivity(i);
            }
        });
        imageView = findViewById(R.id.first);

        // Apply OnClickListener  to imageView to
        // switch from one activity to another
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent class will help to go to next activity using
                // it's object named intent.
                // SecondActivty is the name of new created EmptyActivity.
                Intent intent = new Intent(homepage.this, dark.class);
                startActivity(intent);
            }
        });
        ActionBar actionBar=getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.bottom_nav_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.suggestions:
                Intent d = new Intent(homepage.this, suggestions.class);
                startActivity(d);
                break;
            case R.id.nav_movie:
                Intent s = new Intent(homepage.this, Watchlist.class);
                startActivity(s);
                break;
            case R.id.nav_tv:
                Intent a = new Intent(homepage.this, wishlist.class);
                startActivity(a);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
  //  public boolean onOptionsItemSelected(@NonNull MenuItem item){
  //      switch (item.getItemId()){
  //          case android.R.id.home:
  //              this.finish();
  //              return true;
   //     }
   //     return super.onOptionsItemSelected(item);
  //  }
}